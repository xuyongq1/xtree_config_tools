@echo on
start ../../xtree_config_tools_exe/xtree_config_tools.exe /tree_type.json
exit